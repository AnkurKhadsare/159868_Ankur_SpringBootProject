package com.cg.banking.controllers;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.TransactionRollbackException;
import com.cg.banking.services.BankingServices;
@Controller
public class AccountController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/openingAccount")
	public ModelAndView registerAccount(@Valid@ModelAttribute Account account,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("openAccountPage");
		account= bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account", account);
	}
	@RequestMapping("/depositingPage")
	public ModelAndView deposit(@RequestParam("accountNo")long accountNo,@RequestParam("accountBalance")float accountBalance) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException {
		accountBalance= bankingServices.depositAmount(accountNo, accountBalance);
		return new ModelAndView("DepositSuccessPage", "accountBalance", accountBalance);
	}
	@RequestMapping("/withdrawingPage")
	public ModelAndView withdraw(@RequestParam("accountNo")long accountNo,@RequestParam("accountBalance")float accountBalance,@RequestParam("pinNumber")int pinNumber) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException {
		accountBalance= bankingServices.withdrawAmount(accountNo, accountBalance, pinNumber);
		return new ModelAndView("WithdrawSuccessPage", "accountBalance", accountBalance);
	}
	@RequestMapping("/fundTransferring")
	public ModelAndView fundTransfer(@RequestParam("accountNoTo")long accountNoTo,@RequestParam("accountNoFrom")long accountNoFrom,@RequestParam("accountBalance")float accountBalance,@RequestParam("pinNumber")int pinNumber) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		bankingServices.fundTransfer(accountNoTo, accountNoFrom, accountBalance, pinNumber);
		return new ModelAndView("TransferSuccessPage", "accountBalance", accountBalance);
	}
		@RequestMapping("/accountDetail")
		public ModelAndView accountDetails(@ModelAttribute Account account,@RequestParam("accountNo")long accountNo) throws AccountNotFoundException, BankingServicesDownException {
			account= bankingServices.getAccountDetails(accountNo);
			return new ModelAndView("accountDetailsPage", "account", account);
	}
		
		@RequestMapping("/allAccountDetails")
		public ModelAndView allAccountDetails(@ModelAttribute Account account) throws AccountNotFoundException, BankingServicesDownException {
			ArrayList<Account> accounts= (ArrayList<Account>) bankingServices.getAllAccountDetails();
			return new ModelAndView("allAccountDetailsPage", "accounts", accounts);
	}
		
		@RequestMapping("/transactionDetails")
		public ModelAndView AccountTransaction(@ModelAttribute Transaction transaction,@RequestParam("accountNo")long accountNo) throws AccountNotFoundException, BankingServicesDownException, TransactionRollbackException {
			ArrayList<Transaction> transactions= (ArrayList<Transaction>) bankingServices.getAccountAllTransaction(accountNo);
			return new ModelAndView("accountTransactionsPage", "transactions", transactions);
	}
}