package com.cg.mobilebilling;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.mobilebilling.services.BillingServices;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CgMobileBillingSystemApplicationTests {

	@Autowired
	private BillingServices billingServices;
	
	@Test
	public void contextLoads() {
	}

}
